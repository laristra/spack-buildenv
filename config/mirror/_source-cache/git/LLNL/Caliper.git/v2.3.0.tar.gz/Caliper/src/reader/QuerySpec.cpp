// Copyright (c) 2019, Lawrence Livermore National Security, LLC.
// See top-level LICENSE file for details.

#include "caliper/reader/QuerySpec.h"

const cali::QuerySpec::FunctionSignature cali::QuerySpec::FunctionSignatureTerminator { -1, nullptr, -1, -1, nullptr };
