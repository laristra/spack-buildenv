// Copyright (c) 2019, Lawrence Livermore National Security, LLC.  
// See top-level LICENSE file for details.

#pragma once

#ifdef __cplusplus
#include "caliper/ConfigManager.h"
#include "caliper/ChannelController.h"

extern "C" {
#endif

#ifdef __cplusplus
} // extern "C"
#endif
