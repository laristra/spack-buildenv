Automated continuous integration application tests for Caliper
========================

This directory contains driver scripts and test cases for automated
continuous integration full application/workflow tests.
