// Copyright (c) 2019, Lawrence Livermore National Security, LLC.
// See top-level LICENSE file for details.

// Node class implementation

#include "caliper/common/Node.h"

using namespace cali;

Node::~Node()
{
    // unlink();
}
