CurIOus: I/O wrapping abstraction layer
========

CurIOus is an abstraction layer for wrapping IO functions with Gotcha.
Currently, it supports POSIX IO.

CurIOus was written by Joy Kitson.
