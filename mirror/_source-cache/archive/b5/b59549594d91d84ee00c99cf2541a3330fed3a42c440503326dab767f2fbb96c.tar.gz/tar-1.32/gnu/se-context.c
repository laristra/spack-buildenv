#include <config.h>
#define SE_CONTEXT_INLINE _GL_EXTERN_INLINE
#include <selinux/context.h>
