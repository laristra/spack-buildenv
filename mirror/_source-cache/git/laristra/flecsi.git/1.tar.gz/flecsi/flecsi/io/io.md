<!-- CINCHDOC DOCUMENT(user-guide) SECTION(io) -->

# I/O

--------------------------------------------------------------------------------

<!-- CINCHDOC DOCUMENT(developer-guide) SECTION(io) -->

# I/O

--------------------------------------------------------------------------------

<!-- vim: set tabstop=2 shiftwidth=2 expandtab fo=cqt tw=72 : -->
