<!-- CINCHDOC DOCUMENT(Charter) SECTION(Charter) -->

# NGC Mesh Charter

## Authorities:

## Agents:

## Completion Criteria:

## Resources:

## Constraints:

## Priorities:

## Assumptions:
