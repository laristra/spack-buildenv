<!-- CINCHDOC DOCUMENT(user-guide) SECTION(introduction) -->

# Introduction

\flecsi{} is a set of tools that provide mid- and low-leve interfaces that can
be used to create high-level abstractions and interfaces that are suitable
for computational physicists and computational scientists.

# This Guide...

# The Developer Guide

# Doxygen Documentation

<!-- vim: set tabstop=2 shiftwidth=2 expandtab fo=cqt tw=72 : -->
