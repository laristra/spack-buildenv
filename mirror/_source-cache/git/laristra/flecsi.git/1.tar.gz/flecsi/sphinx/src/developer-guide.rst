.. |br| raw:: html

   <br />

FleCSI Developer Guide
======================

.. toctree::
  :caption: User Guide:

  developer-guide/style-guide
  developer-guide/patterns
  developer-guide/versioning

.. vim: set tabstop=2 shiftwidth=2 expandtab fo=cqt tw=72 :
