.. |br| raw:: html

   <br />

FleCSI Interface Documentation
==============================

.. toctree::

  doxygen/index
  doxygen/function

.. vim: set tabstop=2 shiftwidth=2 expandtab fo=cqt tw=72 :
