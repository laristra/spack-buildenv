.. |br| raw:: html

   <br />

FleCSI Team
===========

.. toctree::

  team/ben
  team/christoph
  team/david
  team/irina
  team/jonas
  team/jonathan
  team/nick
  team/oleg
  team/ollie
  team/karen

.. vim: set tabstop=2 shiftwidth=2 expandtab fo=cqt tw=72 :
