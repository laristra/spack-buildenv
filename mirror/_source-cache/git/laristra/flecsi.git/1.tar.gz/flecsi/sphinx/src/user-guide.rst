.. |br| raw:: html

   <br />

FleCSI User Guide
=================

.. toctree::
  :caption: User Guide:

  user-guide/control
  user-guide/data
  user-guide/execution

.. vim: set tabstop=2 shiftwidth=2 expandtab fo=cqt tw=72 :
