#include <gotcha/gotcha.h>
#include <stdio.h>
void phnglui();
int couldnt_find_a_better_main(int argc, char** argv);
int getX();
