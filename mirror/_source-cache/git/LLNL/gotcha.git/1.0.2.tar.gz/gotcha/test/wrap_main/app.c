#include <stdio.h>
#include "lib.h"
int main(){
  printf("In main main\n");
  return getX();
}
